<h1>Paraguay</h1>

<h2>DVB-T</h2>

https://es.wikipedia.org/wiki/Televisi%C3%B3n_digital_terrestre_en_Paraguay

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Unicanal       | [>](http://45.55.127.106/live/unicanal.m3u8) | <img height="20" src="https://i.imgur.com/brlepuX.png"/> | Unicanal.py |
| 2 | Trece            | [>](https://stream.rpc.com.py/live/trece_src.m3u8) | <img height="30" src="https://i.imgur.com/9kcYqk2.png"/>| Trece.py |
| 3 | ABC TV            | [>](https://d2e809bgs49c6y.cloudfront.net/live/d87c2b7b-9ecf-4e6e-b63b-b32772bd7851/live.isml/d87c2b7b-9ecf-4e6e-b63b-b32772bd7851.m3u8) | <img height="30" src="https://i.imgur.com/tBdgllD.png"/>| ABCTV.py |

<h2>Invalid</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
