<h1>Portugal</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Porto Canal Ⓢ  | [>](https://streamer-a01.videos.sapo.pt/live/portocanal/playlist.m3u8) | <img height="20" src="https://i.imgur.com/wsyvP2H.png"/> | PortoCanal.pt |
| 2   | ADtv Ⓢ         | [>](https://playout172.livextend.cloud/liveiframe/_definst_/ngrp:liveartvabr_abr/playlist.m3u8) | <img height="20" src="https://i.imgur.com/FvlcU3z.png"/> |
| 3   | CNN Portugal    | [>](https://sktv-forwarders.7m.pl/get.php?x=CNN_Portugal) | <img height="20" src="https://i.imgur.com/NYH39xs.png"/> | CNNPortugal.pt |
| 4   | Euronews | [>](https://euronews.alteox.app/hls/pt_stream.m3u8) | <img height="20" src="https://i.imgur.com/8MsbPCU.png"/> | EuronewsPortuguese.fr |
