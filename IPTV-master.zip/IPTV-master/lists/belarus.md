<h1>Belarus</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | 1Mus | [>](http://hz1.teleport.cc/HLS/HD.m3u8) | <img height="20" src="https://i.imgur.com/PozF9MT.png"/> | FirstMusicChannel.by |
| 2   | 8 Kanal Vitebsk Ⓢ | [>](http://95.46.208.8:24433/art) | <img height="20" src="https://i.imgur.com/tjwBSTF.jpg"/> | 8kanal.by |
| 3   | Belros Ⓢ | [>](https://live2.mediacdn.ru/sr1/tro/playlist.m3u8) | <img height="20" src="https://i.imgur.com/HWqxjGl.png"/> | BelRos.ru |
| 4   | Belarus 24 | [>](http://serv30.vintera.tv:8081/belarus24/belarus24/playlist.m3u8) | <img height="20" src="https://i.imgur.com/IyAScOh.jpg"/> | Belarus24.by |
| 5   | Belarus 4 Vitebsk Ⓢ | [>](http://95.46.208.8:26258/belarus4) | <img height="20" src="https://i.imgur.com/TW6Ap71.png"/> | Belarus4Vitebsk.by |
| 6   | CTV Belarus Ⓢ | [>](http://212.98.171.116/HLS/ctvby/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Gz6mSGu.png"/> | STV.by |
| 7   | Hawe TV Vitebsk Ⓢ | [>](http://95.46.208.8:26259/nashe) | <img height="20" src="https://i.imgur.com/HOb5m5f.jpg"/> | NasheTV.by |
| 9   | Pervyy Muzykal'nyy BY Ⓢ | [>](http://rtmp.one.by:1200) | <img height="20" src="https://i.imgur.com/7tFiG6S.jpg"/> | FirstMusicChannel.by |
| 10   | Planeta RTR Ⓢ | [>](https://a3569455801-s26881.cdn.ngenix.net/live/smil:rtrp.smil/chunklist_b1600000.m3u8) | <img height="20" src="https://i.imgur.com/yqRuEJd.png"/> | RTRBelarus.by |
| 11   | Radio HIT Orsk | [>](http://hithd.camsh.orsk.ru/hls/hithd.m3u8) | <img height="20" src="https://i.imgur.com/e2RyN4r.jpg"/> | RadioHit.ru |
| 12   | Vitebsk Telekanal | [>](https://flu.vtv.by/tvt-non-by/tracks-v1a1/mono.m3u8) | <img height="20" src="https://i.imgur.com/FXAqELU.jpg"/> | Vitebsk.by |
