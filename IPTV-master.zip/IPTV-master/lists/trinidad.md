<h1>Trinidad</h1>

| #  | Channel       | Link                                                    | Logo                                                     | EPG id       |
|:--:|:-------------:|:-------------------------------------------------------:|:--------------------------------------------------------:|:------------:|
| 1  | CNC3          | [>](https://sktv-forwarders.7m.pl/get.php?x=CNC3)       | <img height="20" src="https://i.imgur.com/1E73l2j.png"/> | CNC3.tt      |
| 2  | gayelle       | [>](https://sktv-forwarders.7m.pl/get.php?x=gayelle)    | <img height="20" src="https://i.imgur.com/GhWdqLq.jpg"/> |              |
| 3  | Synergy TV    | [>](https://sktv-forwarders.7m.pl/get.php?x=Synergy_TV) | <img height="20" src="https://i.imgur.com/ugAy0UG.jpg"/> | SynergyTV.tt |
| 4  | TTT           | [>](https://sktv-forwarders.7m.pl/get.php?x=TTT)        | <img height="20" src="https://i.imgur.com/rxf4x8J.jpg"/> | TTT.tt       |
| 5  | IBN           | [>](https://sktv-forwarders.7m.pl/get.php?x=IBN)        | <img height="20" src="https://i.imgur.com/hSJGncF.jpg"/> |              |
| 6  | Trinity TV    | [>](https://sktv-forwarders.7m.pl/get.php?x=Trinity_TV) | <img height="20" src="https://i.imgur.com/prgVynR.jpg"/> |              |
