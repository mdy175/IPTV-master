<h1>Denmark</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | DR1     | [>](https://drlive01texthls.akamaized.net/hls/live/2014186/drlive01text/master.m3u8) | <img height="20" src="https://i.imgur.com/wEq8UnG.png"/> | DR1.dk |
| 3   | DR2       | [>](https://drlive02texthls.akamaized.net/hls/live/2014188/drlive02text/master.m3u8) | <img height="20" src="https://i.imgur.com/b79UKYN.png"/> | DR2.dk |
| 4   | DR Ramasjang   | [>](https://drlive03texthls.akamaized.net/hls/live/2014191/drlive03text/master.m3u8) | <img height="20" src="https://i.imgur.com/YD0z2mN.png"/> | DRRamasjang.dk |
