<h1>Finland</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Yle TV1    | [>](https://yletv-lh.akamaihd.net/i/yletv1hls_1@103188/index_4096_av-p.m3u8?sd=6&dw=14400&set-segment-duration=quality&rebase=on) | <img height="20" src="https://i.imgur.com/Hkljcl8.png"/> | YleTV1.fi |
| 2   | Yle TV2  Ⓖ | [>](https://yletv-lh.akamaihd.net/i/yletv2hls_1@103189/index_4096_av-p.m3u8?sd=6&dw=14400&set-segment-duration=quality&rebase=on) | <img height="20" src="https://i.imgur.com/nNElsFg.png"/> | YleTV2.fi |
| 5   | Yle Teema Fem  Ⓖ | [>](https://yletv.akamaized.net/hls/live/622367/yletvteemafemfin/index.m3u8) | <img height="20" src="https://i.imgur.com/iDljufz.png"/> | YleTeemaFem.fi |
| 15  | AlfaTV | [>](https://alfatv.digitacdn.net/live/_definst_/alfatv/amlst:alfatv.amlst/playlist.m3u8?organizationId=4507452&suiteItemId=4515276) | <img height="20" src="https://i.imgur.com/QnJqVAb.png"/> | AlfaTV.fi |
| 19  | INEZ | [>](https://inezsecondary.digitacdn.net/live/_definst_/inez/amlst:inezlive.amlst/master.m3u8?organizationId=14520912&suiteItemId=14521292) | <img height="20" src="https://i.imgur.com/2QEWscr.png"/> |
| 33  | Koti TV | [>](https://kotitv.digitacdn.net/amlst:kotitv.amlst/playlist.m3u8?organizationId=83459409&suiteItemId=83459780) | <img height="20" src="https://i.imgur.com/IgK0pJN.png"/> |
| 45  | Taivas TV7 | [>](https://vod.tv7.fi/tv7-fi/_definst_/smil:tv7-fi.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/a4iNVXA.png"/> | TaivasTV7.fi |
| 46  | Himlen TV7 | [>](https://vod.tv7.fi/tv7-se/_definst_/smil:tv7-se.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/a4iNVXA.png"/> | HimlenTV7.fi |
