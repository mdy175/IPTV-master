<h1>Japan</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | ANN News Ⓨ     | [>](https://www.youtube.com/user/ANNnewsCH/live) | <img height="20" src="https://i.imgur.com/9IVsFXz.png"/> |
| 2   | NHK General TV Ⓢ | [>](https://nhk3.mov3.co/hls/nhk.m3u8) | <img height="20" src="https://i.imgur.com/ns0PHbl.png"/> | NHKGeneralTV.jp |
| 3   | NHK World-Japan | [>](https://nhkwlive-ojp.akamaized.net/hls/live/2003459/nhkwlive-ojp-en/index_4M.m3u8) | <img height="20" src="https://i.imgur.com/TDCuUDs.png"/> | NHKWorldJapan.jp |
| 4   | 日テレ Ⓢ     | [>](https://ntv3.mov3.co/hls/ntv.m3u8) | <img height="20" src="https://i.imgur.com/IGu52nM.png"/> | NipponTV.jp |
| 5   | 日テレNEWS24 Ⓢ     | [>](https://n24-cdn-live.ntv.co.jp/ch01/index.m3u8) | <img height="20" src="https://i.imgur.com/tVNZ0BU.png"/> | NTVNews24.jp |
| 6   | フジテレビ Ⓢ     | [>](https://fujitv3.mov3.co/hls/fujitv.m3u8) | <img height="20" src="https://i.imgur.com/CjoqJXh.png"/> | FujiTV.jp |
| 7   | TBS Ⓢ     | [>](https://tbs2.mov3.co/hls/tbs.m3u8) | <img height="20" src="https://i.imgur.com/SzWJscr.png"/> |
| 8   | TBS News Ⓨ     | [>](https://www.youtube.com/c/tbsnews/live) | <img height="20" src="https://i.imgur.com/hk0oZab.png"/> | TBSNews.jp |
| 9   | BS-TBS         | [>](http://cdnv148.cloudrsst.com:1935/jptv/bstbs_720/playlist.m3u8) | <img height="20" src="https://i.imgur.com/g1pTQIm.png"/> | BSTBS.jp |
| 10  | BSテレ東        | [>](http://cdnv148.cloudrsst.com:1935/jptv/bsjapan_720/playlist.m3u8) | <img height="20" src="https://i.imgur.com/yJfA6ak.png"/> | BSTVTokyo.jp |
| 11  | TV Tokyo     | [>](https://bcsecurelivehls-i.akamaihd.net/hls/live/265320/5043843989001/140130JTDX/index.m3u8) | <img height="20" src="https://i.imgur.com/BMXZjA1.png"/> |
| 12  | Tokyo MX1    | [>](https://movie.mcas.jp/mcas/mx1_2/master.m3u8) | <img height="20" src="https://i.imgur.com/ghRFrKj.png"/> | TokyoMX1.jp |
| 13  | Tokyo MX2    | [>](https://movie.mcas.jp/mcas/mx2_2/master.m3u8) | <img height="20" src="https://i.imgur.com/ghRFrKj.png"/> | TokyoMX2.jp |
| 14  | TV Asahi     | [>](http://redlabmcdn.s.llnwi.net/nv02/ryowa4hd/index.m3u8) | <img height="20" src="https://i.imgur.com/rls8NVc.png"/> | TVAsahi.jp |
| 15  | HTB Ⓨ          | [>](https://www.youtube.com/c/htbnews/live) | <img height="20" src="https://i.imgur.com/A0Wj0Ys.png"/> |
| 16  | Gunma TV    | [>](https://movie.mcas.jp/switcher/smil:mcas8.smil/master.m3u8) | <img height="20" src="https://i.imgur.com/Fik3Nm9.png"/> | GunmaTV.jp |
| 17  | Weathernews     | [>](http://movie.mcas.jp/mcas/wn1_2/master.m3u8) | <img height="20" src="https://i.imgur.com/7YLRtla.png"/> | Weathernews.jp |
| 18  | GSTV            | [>](https://gemstv.wide-stream.net/gemstv01/smil:gemstv01.smil/chunklist.m3u8) | <img height="20" src="https://i.imgur.com/0wds9n8.png"/> | GSTV.jp |
| 19  | QVC Ⓢ          | [>](http://cdn-live1.qvc.jp/iPhone/800/800.m3u8) | <img height="20" src="https://i.imgur.com/B74hZKd.png"/> | QVCJapan.jp |
| 20  | Shop Channel    | [>](http://stream1.shopch.jp/HLS/out1/prog_index.m3u8) | <img height="20" src="https://i.imgur.com/rkdKa5a.png"/> | ShopChannel.jp |
