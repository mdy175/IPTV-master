<h1>Ireland</h1>

<h2>Saorview</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 3   | Virgin Media 1 | [x](http://csm-e.cds1.yospace.com/csm/extlive/tv3ie01,tv3-prd.m3u8) | <img height="20" src="https://i.imgur.com/Tt2Lzil.png"/> | VirginMediaOne.ie |
| 4   | TG4            | [x](http://csm-e.cds1.yospace.com/csm/live/74246610.m3u8) | <img height="20" src="https://i.imgur.com/Etm3Kgq.png"/> | TG4.ie |
| 5   | Virgin Media 2 | [x](http://csm-e.cds1.yospace.com/csm/extlive/tv3ie01,3e-prd.m3u8) | <img height="20" src="https://i.imgur.com/qs8LY2M.png"/> | VirginMediaTwo.ie |
| 6   | Virgin Media 3 | [x](http://csm-e.cds1.yospace.com/csm/extlive/tv3ie01,be3-prd.m3u8) | <img height="20" src="https://i.imgur.com/SSbPIDZ.png"/> | VirginMediaThree.ie |
| 8   | RTE News       | [x](https://live.rte.ie/live/a/channel3/news.isml/.m3u8) | <img height="20" src="https://i.imgur.com/OisW3m0.png"/> | RTENews.ie |

<h2>Invalid</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | RTE One        | [x]() | <img height="20" src="https://i.imgur.com/44tfMTT.png"/> | RTEOne.ie |
| 2   | RTE Two        | [x]() | <img height="20" src="https://i.imgur.com/X7V1Qpk.png"/> | RTE2.ie |
| 7   | RTE Jr         | [x]() | <img height="20" src="https://i.imgur.com/fgpsaqm.png"/> | RTEjr.ie |
