<h1>Switzerland</h1>

<h2>German</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | SRF 1           | [>](http://51.91.73.99:25461/sweden/PM66f7Y43H/25849) | <img height="20" src="https://i.imgur.com/KCPHba2.png"/> | SRF1.ch |
| 2   | SRF Zwei        | [x]() | <img height="20" src="https://i.imgur.com/bddk7KJ.png"/> | SRFzwei.ch |
| 3   | SRF Info        | [x]() | <img height="20" src="https://i.imgur.com/RhIRCe6.png"/> | SRFInfo.ch |
| 4   | TVO             | [>](https://cdnapisec.kaltura.com/p/1719221/sp/171922100/playManifest/entryId/1_t5h46v64/format/applehttp/protocol/https/a.m3u8) | <img height="20" src="https://i.imgur.com/5QFZ05B.png"/> | TVO.ch |

<h2>French</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | RTS Un    | [>](http://hotiptv.site:8080/zkby2013/1d469e6d9e42/67585) | <img height="20" src="https://i.imgur.com/gWuuBZc.png"/> | RTS1.ch |
| 2   | RTS Deux  | [x]() | <img height="20" src="https://i.imgur.com/BFJa8GT.png"/> | RTS2.ch |
| 3   | TVM 3     | [>](http://livevideo.infomaniak.com/streaming/livecast/tvm3/playlist.m3u8) | <img height="20" src="https://i.imgur.com/3v6iZE6.png"/> | TVM3.ch |


<h2>Italian</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | RSI La 1   | [>](http://190.2.155.162/RSI1/index.m3u8) | <img height="20" src="https://i.imgur.com/j8ogbli.png"/> | RSILa1.ch |
| 2   | RSI La 2   | [>](http://190.2.155.162/RSI2/index.m3u8) | <img height="20" src="https://i.imgur.com/vm62h3t.png"/> | RSILa2.ch |
| 3   | Teleticino | [>](https://livestream.gruppocdt.ch/hls/teleticino.m3u8) | <img height="20" src="https://i.imgur.com/zm2ruqz.png"/> | TeleTicino.ch |
