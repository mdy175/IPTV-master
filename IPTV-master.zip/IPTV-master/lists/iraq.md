<h1>Iraq</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Al-Hurra Iraq | [>](https://mbnvvideoingest-i.akamaihd.net/hls/live/1004674/MBNV_ALHURRA_IRAQ/playlist.m3u8) | <img height="20" src="https://i.imgur.com/mXBZEQP.png"/> | AlhurraTVIraq.iq |
| 2   | Al-Hurra            | [>](https://mbnvvideoingest-i.akamaihd.net/hls/live/1004673/MBNV_ALHURRA_MAIN/playlist.m3u8) | <img height="20" src="https://i.imgur.com/0izeu5z.png"/> | AlHurra.iq |
| 3   | Al-Iraqiya | [>](https://cdn.catiacast.video/abr/8d2ffb0aba244e8d9101a9488a7daa05/playlist.m3u8) | <img height="20" src="https://i.imgur.com/imdV6kL.png"/> |
| 4   | Al-Rafidain       | [>](https://cdg8.edge.technocdn.com/arrafidaintv/abr_live/playlist.m3u8) | <img height="20" src="https://i.imgur.com/D78qG91.png"/> | AlRafidainTV.iq |
| 5   | Al-Rasheed       | [>](https://media1.livaat.com/AL-RASHEED-HD/tracks-v1a1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/SU9HbXY.png"/> | AlRasheedTV.iq |
| 6   | Al-Sharqiya News       | [>](https://5d94523502c2d.streamlock.net/alsharqiyalive/mystream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/P6p17ZY.jpg"/> | AlSharqiyaNews.iq |
| 7   | Al-Sharqiya       | [>](https://5d94523502c2d.streamlock.net/home/mystream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/bPYyXNf.png"/> | AlSharqiya.iq |
| 8   | Dijlah Tarab       | [>](https://ghaasiflu.online/tarab/tracks-v1a1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/2SBjjBQ.png"/> | DijlahTarab.iq |
| 9   | Dijlah TV       | [>](https://ghaasiflu.online/Dijlah/tracks-v1a1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/FJEeYiz.png"/> | DijlahTV.iq |
| 10  | iNEWS       | [>](https://svs.itworkscdn.net/inewsiqlive/inewsiq.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/PeuBkaH.png"/> | INews.iq |
| 11  | Iraq Future Ⓢ       | [>](https://streaming.viewmedia.tv/viewsatstream40/viewsatstream40.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Z7woTe5.png"/> | IraqFuture.iq |
| 12  | Turkmeneli TV       | [>](https://137840.global.ssl.fastly.net/edge/live_6b7c6e205afb11ebb010f5a331abaf98/playlist.m3u8) | <img height="20" src="https://i.imgur.com/iUhhg4B.png"/> | TurkmeneliTV.iq |
| 13  | Zagros TV       | [>](https://5a3ed7a72ed4b.streamlock.net/zagrostv/SMIL:myStream.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/UjIuIQX.png"/> | ZagrosTV.iq |
