<h1>Croatia</h1>

| # | Channel            | Link                                                                 | Logo                                                     | EPG id              |
|:-:|:------------------:|:--------------------------------------------------------------------:|:--------------------------------------------------------:|:-------------------:|
| 1 | RTL                | [>](https://d1cs5tlhj75jxe.cloudfront.net/rtl/playlist.m3u8)         | <img height="20" src="https://i.imgur.com/zAjr6pO.png"/> | RTLCroatia.hr       |
| 2 | RTL2               | [>](https://d1um9c09e0t5ag.cloudfront.net/rtl2/playlist.m3u8)        | <img height="20" src="https://i.imgur.com/dQLaylJ.png"/> | RTL2Croatia.hr      |
| 3 | RTL Kockica        | [>](https://d1rzyyum8t0q1e.cloudfront.net/rtl-kockica/playlist.m3u8) | <img height="20" src="https://i.imgur.com/BiSVmRa.png"/> | RTLKockica.hr       |
| 4 | CMC TV             | [>](https://stream.cmctv.hr:49998/cmc/live.m3u8)                     | <img height="20" src="https://i.imgur.com/Fh2vawT.png"/> | CMCTV.hr            |
| 5 | Al Jazeera Balkans | [>](https://live-hls-web-ajb.getaj.net/AJB/index.m3u8)               | <img height="20" src="https://i.imgur.com/Z1FB6wl.png"/> | AlJazeeraBalkans.qa |
