<h1>Russia</h1>

<h2>DVB-T2</h2>

https://ru.wikipedia.org/wiki/%D0%A6%D0%B8%D1%84%D1%80%D0%BE%D0%B2%D0%BE%D0%B5_%D1%82%D0%B5%D0%BB%D0%B5%D0%B2%D0%B8%D0%B4%D0%B5%D0%BD%D0%B8%D0%B5_%D0%B2_%D0%A0%D0%BE%D1%81%D1%81%D0%B8%D0%B8#%D0%9C%D1%83%D0%BB%D1%8C%D1%82%D0%B8%D0%BF%D0%BB%D0%B5%D0%BA%D1%81%D1%8B (only in Russian language)

|  # |      Channel       | Link  | Logo | EPG id |
|:--:|:------------------:|:-----:|:----:|:------:|
|  1 |   Первый канал Ⓢ   | [>](http://iptv.ktkru.ru:8001/index.m3u8) | <img height="20" src="https://i.imgur.com/1IqCGe9.png"/> | ChannelOne.ru |
|  2 |     Россия 1 Ⓢ     | [>](http://iptv.ktkru.ru:8002/index.m3u8) | <img height="20" src="https://i.imgur.com/WI6hKez.png"/> | Russia1.ru |
|  3 |     Матч ТВ Ⓢ      | [>](http://iptv.ktkru.ru:8003/index.m3u8) | <img height="20" src="https://i.imgur.com/kFdooR4.png"/> | Match.ru |
|  4 |       НТВ Ⓢ        | [>](http://iptv.ktkru.ru:8004/index.m3u8) | <img height="20" src="https://i.imgur.com/DtQX5P2.png"/> | NTV.ru |
|  5 |   Пятый канал Ⓢ    | [>](http://iptv.ktkru.ru:8005/index.m3u8) | <img height="20" src="https://i.imgur.com/u8Q69D9.png"/> | 5Kanal.ru |
|  6 | Россия-Культура Ⓢ  | [>](http://iptv.ktkru.ru:8006/index.m3u8) | <img height="20" src="https://i.imgur.com/S12gaLc.png"/> | RussiaK.ru |
|  7 |    Россия-24 Ⓢ     | [>](http://iptv.ktkru.ru:8007/index.m3u8) | <img height="20" src="https://i.imgur.com/tpqsFzm.png"/> | Russia24.ru |
|  8 |     Карусель Ⓢ     | [>](http://iptv.ktkru.ru:8008/index.m3u8) | <img height="20" src="https://i.imgur.com/4fFMlVq.png"/> | Karusel.ru |
|  9 |       ОТР Ⓢ        | [>](http://iptv.ktkru.ru:8009/index.m3u8) | <img height="20" src="https://i.imgur.com/QyZvT3e.png"/> | OTR.ru |
| 10 |     ТВ Центр Ⓢ     | [>](http://iptv.ktkru.ru:8010/index.m3u8) | <img height="20" src="https://i.imgur.com/ZP0D6Rd.png"/> | TVCentr.ru |
| 11 |      Рен ТВ Ⓢ      | [>](http://iptv.ktkru.ru:8011/index.m3u8) | <img height="20" src="https://i.imgur.com/18TAzYV.png"/> | RENTV.ru |
| 12 |       Спас Ⓢ       | [>](http://iptv.ktkru.ru:8012/index.m3u8) | <img height="20" src="https://i.imgur.com/A6Cqsom.jpeg"/> | TelekanalSpas.ru |
| 13 |       СТС Ⓢ        | [>](http://iptv.ktkru.ru:8013/index.m3u8) | <img height="20" src="https://i.imgur.com/y9bpqUD.png"/> | STS.ru |
| 14 |     Домашний Ⓢ     | [>](http://iptv.ktkru.ru:8014/index.m3u8) | <img height="20" src="https://i.imgur.com/e8wlMIt.png"/> | Domashniy.ru |
| 15 |       ТВ-3 Ⓢ       | [>](http://iptv.ktkru.ru:8015/index.m3u8) | <img height="20" src="https://i.imgur.com/kjaxZms.png"/> | TV3.ru |
| 16 |     Пятница! Ⓢ     | [>](http://iptv.ktkru.ru:8016/index.m3u8) | <img height="20" src="https://i.imgur.com/rS11zVB.png"/> | Pyatnitsa.ru |
| 17 |      Звезда Ⓢ      | [>](http://iptv.ktkru.ru:8017/index.m3u8) | <img height="20" src="https://i.imgur.com/c0L0ncA.png"/> | TelekanalZvezda.ru |
| 18 |        Мир         | [>](http://hls.mirtv.cdnvideo.ru/mirtv-parampublish/mirtv_2500/playlist.m3u8) | <img height="20" src="https://i.imgur.com/L2slsbG.png"/> | Mir.ru |
| 19 |       ТНТ Ⓢ        | [>](http://iptv.ktkru.ru:8019/index.m3u8) | <img height="20" src="https://i.imgur.com/1WqIPOB.png"/> | TNT.ru |
| 20 |      Муз-ТВ Ⓢ      | [>](http://iptv.ktkru.ru:8020/index.m3u8) | <img height="20" src="https://i.imgur.com/Ml3qqOF.png"/> | MuzTV.ru |
| 21 |        РБК         | [>](http://92.50.128.180/utv/1358/index.m3u8) | <img height="20" src="https://i.imgur.com/P2Qii5B.png"/> | RBKTV.ru |
| 22 |     RT Д Русский   | [>](https://strm.yandex.ru/kal/rtd_hd/rtd_hd0.m3u8) | <img height="20" src="https://i.imgur.com/v5fpEBo.png"/> | RTD.ru |
| 23 |    CGTN Pусский    | [>](https://news.cgtn.com/resource/live/russian/cgtn-r.m3u8) | <img height="20" src="https://i.imgur.com/fMsJYzl.png"/> | CGTNRussian.cn |
| 24 | Euronews по-русски | [>](https://euronews.alteox.app/hls/ru_stream.m3u8) | <img height="20" src="https://i.imgur.com/8MsbPCU.png"/> | EuronewsRussian.fr |

<h2>Invalid</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
