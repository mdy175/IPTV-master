<h1>Czech Republic</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | JOJ Family Ⓢ    | [>](https://live.cdn.joj.sk/live/hls/family-540.m3u8) | <img height="20" src="https://i.imgur.com/IZHIAAj.png"/> | JojFamily.sk |
| 2   | Šlágr Originál Ⓢ    | [>](https://stream-6.mazana.tv/slagr.m3u) | <img height="20" src="https://i.imgur.com/fQcx9S2.png"/> | SlagrOriginal.cz |
| 3   | Šlágr Muzika Ⓢ    | [>](https://stream-33.mazana.tv/slagr2.m3u) | <img height="20" src="https://i.imgur.com/J9YHDVS.png"/> | SlagrMuzika.cz |
| 4   | Šlágr Premium Ⓢ    | [>](https://stream-15.mazana.tv/slagrpremium.m3u) | <img height="20" src="https://i.imgur.com/Lp0IqDx.png"/> | SlagrPremium.cz |
| 5   | Prima Ⓢ Ⓖ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_family/playlist/cze/live_hq.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/0aHT2Nj.png"> | Prima.cz |
| 6   | CNN Prima News Ⓢ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_cnn/playlist/cze/live_hq.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/Il7t0bU.png"> | CNNPrimaNews.cz |
| 7   | Prima Zoom Ⓢ Ⓖ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_zoom/playlist/cze/live_hq.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/zuzBucZ.png"> | PrimaZoom.cz |
| 8   | Prima Love Ⓢ Ⓖ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_love/playlist/cze/live_hq.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/TOCZc3Y.png"> | PrimaLove.cz |
| 9   | Prima STAR Ⓢ Ⓖ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_star/playlist/cze/live_hq.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/tQGwvNs.png"> | PrimaStar.cz |
| 10  | Prima Krimi Ⓢ Ⓖ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_krimi/playlist/cze/live_hq.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/Dn2YxrA.png"> | PrimaKrimi.cz |
| 11  | Prima MAX Ⓢ Ⓖ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_max/playlist/cze/live_hq.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/QaEakvm.png"> | PrimaMax.cz |
| 12  | Prima Cool Ⓢ Ⓖ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_cool/playlist/cze/live_hq.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/JMHWmcJ.png"> | PrimaCool.cz |
| 13  | Prima Show Ⓢ Ⓖ   | [>](https://prima-ott-live.ssl.cdn.cra.cz/channels/prima_show/playlist/cze/live_hq.m3u8?offsetSeconds=0&url=0) | <img height="20" src="https://i.imgur.com/zX4NTJ5.png"> | PrimaShow.cz |
| 14  | Óčko Ⓢ    | [>](https://ocko-live.ssl.cdn.cra.cz/channels/ocko/playlist.m3u8) | <img height="20" src="https://i.imgur.com/iPmpsnN.png"/> | Ocko.cz |
| 15  | Óčko Star Ⓢ    | [>](https://ocko-live.ssl.cdn.cra.cz/channels/ocko_gold/playlist.m3u8) | <img height="20" src="https://i.imgur.com/tGzQFWw.png"/> | OckoStar.cz |
| 16  | Óčko Expres Ⓢ    | [>](https://ocko-live.ssl.cdn.cra.cz/channels/ocko_expres/playlist.m3u8) | <img height="20" src="https://i.imgur.com/e731JNS.png"/> | OckoExpres.cz |
| 17  | Retro Music Television Ⓢ    | [>](https://stream.mediawork.cz/retrotv/smil:retrotv2.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/a6S2Yo4.png"/> | RetroMusicTV.cz |
