<h1>Malta</h1>

<h2>DVB-T</h2>

https://en.wikipedia.org/wiki/List_of_television_stations_in_Malta

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 4   | ONE TV         | [>](https://2-fss-2.streamhoster.com/pl_124/201830-1293592-1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Ym1L7No.png"/> | One.mt |
| 5   | Smash TV       | [>](http://a3.smashmalta.com/hls/smash/smash.m3u8) | <img height="20" src="https://i.imgur.com/ZKF0fG3.png"/> | SmashTV.mt |

<h2>Invalid</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | TVM Ⓢ          | [x]() | <img height="20" src="https://i.imgur.com/6jaNiUi.png"/> | TVM.mt |
| 2   | TVM 2 Ⓢ        | [x]() | <img height="20" src="https://i.imgur.com/qUZxPez.png"/> |
| 3   | NET TV         | [x]() | <img height="20" src="https://i.imgur.com/DcXBpzx.png"/> | NetTV.mt |
| 6   | F Living       | [x]() | <img height="20" src="https://i.imgur.com/mAbciXA.png"/> | FLivingChannel.mt |
