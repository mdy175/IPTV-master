<h1>Slovenia</h1>

<h2>DVB-T</h2>

https://en.wikipedia.org/wiki/Television_in_Slovenia

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | RTV SLO 1      | [>](https://31-rtvslo-tv-slo1-int.cdn.eurovisioncdn.net/playlist.m3u8) | <img height="20" src="https://i.imgur.com/YIZOtcm.png"/> | TVSlovenija1.si |
| 2   | RTV SLO 2      | [>](https://21-rtvslo-tv-slo2-int.cdn.eurovisioncdn.net/playlist.m3u8) | <img height="20" src="https://i.imgur.com/mQe9U2h.png"/> | TVSlovenija2.si |
| 3   | RTV SLO 3      | [>](https://16-rtvslo-tv-slo3-int.cdn.eurovisioncdn.net/playlist.m3u8) | <img height="20" src="https://i.imgur.com/WGUyj7r.png"/> | TVSlovenija3.si |
| 4   | TV Koper       | [>](https://27-rtvslo-tv-kp-int.cdn.eurovisioncdn.net/playlist.m3u8) | <img height="20" src="https://i.imgur.com/NQvOJNh.png"/> | TVKoperCapodistria.si |
| 5   | TV Maribor     | [>](https://25-rtvslo-tv-mb-int.cdn.eurovisioncdn.net/playlist.m3u8) | <img height="20" src="https://i.imgur.com/tWf3dgf.png"/> | TVMaribor.si |
| 6   | MMC TV         | [>](https://29-rtvslo-tv-mmc-int.cdn.eurovisioncdn.net/playlist.m3u8) | <img height="20" src="https://i.imgur.com/yzETQJ4.png"/> | MMC.si |

<h2>Invalid</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
