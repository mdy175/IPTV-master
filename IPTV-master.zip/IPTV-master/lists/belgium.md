<h1>Belgium</h1>

<h2>Wallonia</h2>

| #   | Channel         | Link  | Logo | EPG id |
|:---:|:---------------:|:-----:|:----:|:------:|
| 1   | RTL-Be          | [>](https://rtltvi-lh.akamaihd.net/i/TVI_1@319659/master.m3u8) | <img height="20" src="https://i.imgur.com/xMhSvax.png"/> | BelRTL.be |
| 2   | La Une          | [>](http://4ce5e2d62ee2c10e43c709f9b87c44d5.streamhost.cc/m3u8/Belgium/29797c9f3f4fa00.m3u8) | <img height="20" src="https://i.imgur.com/hJodwJt.png"/> | LaUne.be |
| 3   | Tipik           | [>](http://4ce5e2d62ee2c10e43c709f9b87c44d5.streamhost.cc/m3u8/Belgium/5dee2de1f4661ce.m3u8) | <img height="20" src="https://i.imgur.com/PVbVj8o.png"/> | Tipik.be |
| 4   | Club RTL        | [>](http://4ce5e2d62ee2c10e43c709f9b87c44d5.streamhost.cc/m3u8/Belgium/9ef55f75bc15308.ts) | <img height="20" src="https://i.imgur.com/e9GkFwY.png"/> | ClubRTL.be |
| 5   | Arte Belgique   | [x]() | <img height="20" src="https://i.imgur.com/w7HzPQh.png"/> | 
| 6   | La Trois        | [>](http://4ce5e2d62ee2c10e43c709f9b87c44d5.streamhost.cc/m3u8/Belgium/6f940c7da9a562e.ts) | <img height="20" src="https://i.imgur.com/kC3pJtA.png"/> | LaTrois.be |
| 7   | Be 1            | [x]() | <img height="20" src="https://i.imgur.com/atSjuXK.png"/> | Be1.be |
| 8   | TV5 Monde       | [x]() | <img height="20" src="https://i.imgur.com/7WHwYK3.png"/> | 
| 9   | Plug RTL        | [>](http://4ce5e2d62ee2c10e43c709f9b87c44d5.streamhost.cc/m3u8/Belgium/de5c6896d356f8e.ts) | <img height="20" src="https://i.imgur.com/iAZZWkZ.png"/> | PlugRTL.be |
| 10  | AB3             | [x]() | <img height="20" src="https://i.imgur.com/7foaAFU.png"/> | AB3.be |
| 11  | ABXplore        | [x]() | <img height="20" src="https://i.imgur.com/KwV8axc.png"/> | ABXplore.be |
| 12  | LN24            | [>](https://live.cdn.ln24.be/out/v1/b191621c8b9a436cad37bb36a82d2e1c/index.m3u8) | <img height="20" src="https://i.imgur.com/hePpxnn.png"/> | LN24.be |
| 13  | BX1             | [>](https://59959724487e3.streamlock.net/stream/live/playlist.m3u8) | <img height="20" src="https://i.imgur.com/YjKqWru.png"/> | BX1.be |

<h2>Flanders</h2>

| #   | Channel   | Link  | Logo | EPG id |
|:---:|:---------:|:-----:|:----:|:------:|
| 1   | EEN       | [>](https://live-vrt.rabah.net/groupc/live/8edf3bdf-7db3-41c3-a318-72cb7f82de66/live_aes.isml/playlist.m3u8) | <img height="20" src="https://i.imgur.com/66GQlc7.png"/> | Een.be |
| 2   | Canvas    | [>](http://4ce5e2d62ee2c10e43c709f9b87c44d5.streamhost.cc/m3u8/Belgium/09916e3a88db175.ts) | <img height="20" src="https://i.imgur.com/GQkhACx.png"/> | Canvas.be |
| 3   | VTM       | [>](http://4ce5e2d62ee2c10e43c709f9b87c44d5.streamhost.cc/m3u8/Belgium/c5cafdbfc4d28d3.ts) | <img height="20" src="https://i.imgur.com/fUxRP9x.png"/> | VTM.be |
| 4   | VTM 2     | [x]() | <img height="20" src="https://i.imgur.com/bL0fD77.png"/> | VTM2.be |
| 5   | VIER      | [>](http://4ce5e2d62ee2c10e43c709f9b87c44d5.streamhost.cc/m3u8/Belgium/3f1f349cb9cf765.ts) | <img height="20" src="https://i.imgur.com/bFTXP2e.png"/> |
| 6   | VIJF      | [>](http://4ce5e2d62ee2c10e43c709f9b87c44d5.streamhost.cc/m3u8/Belgium/7f59a4dfcc56366.ts) | <img height="20" src="https://i.imgur.com/DTJLkiP.png"/> |
| 7   | VTM 3     | [x]() | <img height="20" src="https://i.imgur.com/NTN8ixi.png"/> | VTM3.be |
| 8   | VTM 4     | [x]() | <img height="20" src="https://i.imgur.com/A7Mi1rY.png"/> | VTM4.be |
