<h1>Sweden</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | SVT 1    Ⓖ | [>](https://ed2.cdn.svt.se/ed7/d1/c/se/svt1/manifest.mpd?defaultSubLang=1) | <img height="20" src="https://i.imgur.com/ZoBXmOO.png"/> | SVT1.se |
| 2   | SVT 2   Ⓖ | [>](https://ed2.cdn.svt.se/ed7/d1/c/se/svt2/manifest.mpd?defaultSubLang=1) | <img height="20" src="https://i.imgur.com/iB3veGx.png"/> | SVT2.se |
| 4   | TV4       | [x]() | <img height="20" src="https://i.imgur.com/nyLmev6.png"/> | TV4.se |
| 5   | Kanal 5   | [x]() | <img height="20" src="https://i.imgur.com/8FeQ4ev.png"/> | Kanal5.se |
| 24   | SVT 24   Ⓖ | [>](https://ed2.cdn.svt.se/ed7/d1/c/se/svtb/manifest.mpd?defaultSubLang=1) | <img height="20" src="https://i.imgur.com/o9M7Tiq.png"/> | SVT24.se |
| 43   | Expressen TV    | [>](https://cdn0-03837-liveedge0.dna.ip-only.net/03837-liveedge0/smil:03837-tx2/playlist.m3u8) | <img height="20" src="https://i.imgur.com/8EjMSr7.png"/> | ExpressenTV.se |
| 99   | Kunskapskanalen   Ⓖ | [>](https://ed2.cdn.svt.se/ed7/d1/c/se/svtk/manifest.mpd?defaultSubLang=1) | <img height="20" src="https://i.imgur.com/9YBxoGc.png"/> | Kunskapskanalen.se |
| 109  | Kanal 10    | [>](https://rrr.sz.xlcdn.com/?account=cn_kanal10media&file=live_transcoded&type=live&service=wowza&protocol=https&output=playlist.m3u8) | <img height="20" src="https://i.imgur.com/vlh699v.png"/> | Kanal10.se |
